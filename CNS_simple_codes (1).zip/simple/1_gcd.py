# ======================================================================
# EXPERIMENT 1 : EUCLIDEAN ALGORITHM
# File : 1_gcd.py - GCD, Extended GCD and Multiplicative Inverse
# ======================================================================
#
# WHAT IS INSIDE THIS FILE
#   Part A - GCD using the Euclidean algorithm
#   Part B - Extended Euclidean algorithm (finds s and t)
#   Part C - Multiplicative inverse (a mod m)
#
# HOW TO RUN
#   1. Run          : python 1_gcd.py   (python3 on Linux/macOS)
#
# SAMPLE INPUT : 240, 46, 17, 3120 (one per line)
#
# EXPECTED OUTPUT (what you will see in the terminal)
#   Enter first number: 240
#   Enter second number: 46
#   GCD = 2
#   Extended: s = -9  t = 47  -> 240*(-9) + 46*(47) = 2
#   Inverse of a: 17
#   modulo m: 3120
#   Inverse = 2753
# ======================================================================


# ---------- PART A: GCD (Euclidean algorithm) ----------
def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

# ---------- PART B: EXTENDED EUCLIDEAN ALGORITHM (returns gcd, s, t) ----------
def ext_gcd(a, b):
    if b == 0:
        return a, 1, 0
    g, s, t = ext_gcd(b, a % b)
    return g, t, s - (a // b) * t

# ---------- MAIN PROGRAM: take input and print results ----------
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
print("GCD =", gcd(a, b))
g, s, t = ext_gcd(a, b)
print("Extended: s =", s, " t =", t, " ->", f"{a}*({s}) + {b}*({t}) = {a*s + b*t}")

# ---------- PART C: MULTIPLICATIVE INVERSE ----------
a2, m = int(input("Inverse of a: ")), int(input("modulo m: "))
g, s, _ = ext_gcd(a2, m)
print("Inverse =", s % m if g == 1 else "does not exist")
