# ======================================================================
# EXPERIMENT 5 : ASYMMETRIC (PUBLIC KEY) ALGORITHMS
# File : 5_asymmetric.py - RSA, ElGamal, Diffie-Hellman and ECC (small fixed numbers)
# ======================================================================
#
# WHAT IS INSIDE THIS FILE
#   Part A - RSA encrypt / decrypt
#   Part B - ElGamal encrypt / decrypt
#   Part C - Diffie-Hellman key exchange
#   Part D - Elliptic Curve Cryptography (ECC) encrypt / decrypt
#
# HOW TO RUN
#   1. Run          : python 5_asymmetric.py   (python3 on Linux/macOS)
#
# SAMPLE INPUT : 1234
#
# EXPECTED OUTPUT (what you will see in the terminal)
#   Enter a number (1-3000): 1234
#   RSA      : ciphertext = 1643841 | decrypted = 1234
#   ElGamal  : ciphertext = (128, 27185) | decrypted = 1234
#   DH       : Alice key = 237784 | Bob key = 237784
#   ECC      : ciphertext = ((3572, 13101), 13750) | decrypted = 1234
# ======================================================================


# ---------- INPUT: message number ----------
m = int(input("Enter a number (1-3000): "))

# ---------- PART A: RSA ----------
p, q = 5639, 7589
n, phi = p * q, (p - 1) * (q - 1)
e = 65537
d = pow(e, -1, phi)
c = pow(m, e, n)
print("RSA      : ciphertext =", c, "| decrypted =", pow(c, d, n))

# ---------- PART B: ELGAMAL ----------
p, g, x, k = 32413, 2, 725, 7
y = pow(g, x, p)
c1, c2 = pow(g, k, p), m * pow(y, k, p) % p
print("ElGamal  : ciphertext =", (c1, c2), "| decrypted =", c2 * pow(pow(c1, x, p), -1, p) % p)

# ---------- PART C: DIFFIE-HELLMAN ----------
p, g, a, b = 731593, 5, 215284, 470208
A, B = pow(g, a, p), pow(g, b, p)
print("DH       : Alice key =", pow(B, a, p), "| Bob key =", pow(A, b, p))

# ---------- PART D: ECC (elliptic curve point add / multiply, then encrypt) ----------
# ---- ECC (curve y^2 = x^3 + 2x + 21 mod 15013, G = (2, 6465)) ----
P, a_, G = 15013, 2, (2, 6465)

def add(p1, p2):
    if p1 is None: return p2
    if p2 is None: return p1
    (x1, y1), (x2, y2) = p1, p2
    if x1 == x2 and (y1 + y2) % P == 0: return None
    if p1 == p2: l = (3 * x1 * x1 + a_) * pow(2 * y1, -1, P) % P
    else:        l = (y2 - y1) * pow(x2 - x1, -1, P) % P
    x3 = (l * l - x1 - x2) % P
    return (x3, (l * (x1 - x3) - y1) % P)

def mul(k, pt):
    r = None
    while k:
        if k & 1: r = add(r, pt)
        pt = add(pt, pt)
        k >>= 1
    return r

priv = 204
Q = mul(priv, G)
k = 57
R = mul(k, G)
cc = (m + mul(k, Q)[0]) % P
print("ECC      : ciphertext =", (R, cc), "| decrypted =", (cc - mul(priv, R)[0]) % P)
