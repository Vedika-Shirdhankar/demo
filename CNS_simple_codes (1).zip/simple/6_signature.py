# ======================================================================
# EXPERIMENT 6 : DIGITAL SIGNATURES
# File : 6_signature.py - Digital signatures with RSA-PSS and ECDSA
# ======================================================================
#
# WHAT IS INSIDE THIS FILE
#   Part A - RSA-PSS key generation and signing
#   Part B - ECDSA key generation and signing
#   Part C - Verification of original and tampered message
#
# HOW TO RUN
#   1. Install once : pip install cryptography
#   2. Run          : python 6_signature.py   (python3 on Linux/macOS)
#
# SAMPLE INPUT : Hello Bob
#
# EXPECTED OUTPUT (what you will see in the terminal)
#   Enter message: Hello Bob
#   RSA-PSS original : PASS
#   RSA-PSS modified : FAIL
#   ECDSA   original : PASS
#   ECDSA   modified : FAIL
#   Signature sizes  : RSA = 256 bytes, ECDSA = 71 bytes
# ======================================================================


from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, ec, padding
from cryptography.exceptions import InvalidSignature

# ---------- INPUT: message and a tampered copy ----------
msg = input("Enter message: ").encode()
fake = msg + b"!"                      # tampered message

# ---------- PART A: RSA-PSS SIGN ----------
rsa_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
pss = padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32)
rsa_sig = rsa_key.sign(msg, pss, hashes.SHA256())

# ---------- PART B: ECDSA SIGN ----------
ec_key = ec.generate_private_key(ec.SECP256R1())
ec_sig = ec_key.sign(msg, ec.ECDSA(hashes.SHA256()))

# ---------- PART C: VERIFY (PASS / FAIL) ----------
def check(verify_fn):
    try:
        verify_fn()
        return "PASS"
    except InvalidSignature:
        return "FAIL"

pub = rsa_key.public_key()
print("RSA-PSS original :", check(lambda: pub.verify(rsa_sig, msg, pss, hashes.SHA256())))
print("RSA-PSS modified :", check(lambda: pub.verify(rsa_sig, fake, pss, hashes.SHA256())))
pub = ec_key.public_key()
print("ECDSA   original :", check(lambda: pub.verify(ec_sig, msg, ec.ECDSA(hashes.SHA256()))))
print("ECDSA   modified :", check(lambda: pub.verify(ec_sig, fake, ec.ECDSA(hashes.SHA256()))))
print("Signature sizes  : RSA =", len(rsa_sig), "bytes, ECDSA =", len(ec_sig), "bytes")
