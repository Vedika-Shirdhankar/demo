# ======================================================================
# EXPERIMENT 3 : PRIMALITY TESTS
# File : 3_primality.py - Fermat, Euler and Miller-Rabin primality tests
# ======================================================================
#
# WHAT IS INSIDE THIS FILE
#   Helper - Jacobi symbol (used by Euler test)
#   Part A - Fermat primality test
#   Part B - Euler (Solovay-Strassen) test
#   Part C - Miller-Rabin test
#   Main - input a number and run all three tests
#
# HOW TO RUN
#   1. Run          : python 3_primality.py   (python3 on Linux/macOS)
#
# SAMPLE INPUT : 561 (a composite number that fools Fermat)
#
# EXPECTED OUTPUT (what you will see in the terminal)
#   Enter a number (odd, > 5): 561
#   Fermat       : Probably PRIME
#   Euler        : COMPOSITE
#   Miller-Rabin : COMPOSITE
# ======================================================================


from math import gcd

# ---------- BASES USED FOR ALL TESTS ----------
BASES = [2, 3, 5, 7, 11]

# ---------- HELPER: JACOBI SYMBOL ----------
def jacobi(a, n):
    a %= n
    r = 1
    while a:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5):
                r = -r
        a, n = n, a
        if a % 4 == 3 and n % 4 == 3:
            r = -r
        a %= n
    return r if n == 1 else 0

# ---------- PART A: FERMAT TEST ----------
def fermat(n):
    return all(pow(a, n - 1, n) == 1 for a in BASES if a < n and gcd(a, n) == 1)

# ---------- PART B: EULER TEST ----------
def euler(n):
    return all(pow(a, (n - 1) // 2, n) == jacobi(a, n) % n for a in BASES if a < n and gcd(a, n) == 1)

# ---------- PART C: MILLER-RABIN TEST ----------
def miller_rabin(n):
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in BASES:
        if a >= n:
            continue
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        if all((x := x * x % n) != n - 1 for _ in range(r - 1)):
            return False
    return True

# ---------- MAIN PROGRAM: input and results ----------
n = int(input("Enter a number (odd, > 5): "))
if n % 2 == 0 or n < 7:
    print("Please enter an odd number greater than 5")
else:
    for name, f in [("Fermat", fermat), ("Euler", euler), ("Miller-Rabin", miller_rabin)]:
        print(f"{name:13}:", "Probably PRIME" if f(n) else "COMPOSITE")
