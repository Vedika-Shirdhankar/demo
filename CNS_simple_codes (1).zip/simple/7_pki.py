# ======================================================================
# EXPERIMENT 7 : PUBLIC KEY INFRASTRUCTURE (PKI)
# File : 7_pki.py - Two-tier PKI (Root -> Intermediate -> Server cert) with CRL revocation
# ======================================================================
#
# WHAT IS INSIDE THIS FILE
#   Part A - Helper functions to build and check X.509 certificates
#   Part B - Root CA, Intermediate CA and Server certificate
#   Part C - Chain verification
#   Part D - CRL (certificate revocation list) check
#
# HOW TO RUN
#   1. Install once : pip install cryptography
#   2. Run          : python 7_pki.py   (python3 on Linux/macOS)
#
# SAMPLE INPUT : none
#
# EXPECTED OUTPUT (what you will see in the terminal)
#   CN=Lab Root CA         issued by CN=Lab Root CA
#   CN=Lab Intermediate CA issued by CN=Lab Root CA
#   CN=server.lab.local    issued by CN=Lab Intermediate CA
#
#   Chain verification: OK (server -> intermediate -> root)
#   Server certificate in CRL: REVOKED
# ======================================================================


import datetime
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding

now = datetime.datetime.now(datetime.timezone.utc)

# ---------- PART A: HELPER FUNCTIONS ----------
def make(cn, key, issuer_name, issuer_key, is_ca, days=365, path_len=None):
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    b = (x509.CertificateBuilder().subject_name(name).issuer_name(issuer_name)
         .public_key(key.public_key()).serial_number(x509.random_serial_number())
         .not_valid_before(now).not_valid_after(now + datetime.timedelta(days=days))
         .add_extension(x509.BasicConstraints(ca=is_ca, path_length=path_len), critical=True))
    return b.sign(issuer_key, hashes.SHA256())

def signed_by(cert, issuer):
    issuer.public_key().verify(cert.signature, cert.tbs_certificate_bytes,
                               padding.PKCS1v15(), cert.signature_hash_algorithm)

# ---------- PART B: CREATE ROOT CA, INTERMEDIATE CA, SERVER CERT ----------
new = lambda: rsa.generate_private_key(public_exponent=65537, key_size=2048)
root_key, inter_key, srv_key = new(), new(), new()

root = make("Lab Root CA", root_key, x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Lab Root CA")]), root_key, True, 3650)
inter = make("Lab Intermediate CA", inter_key, root.subject, root_key, True, 1825, path_len=0)
server = make("server.lab.local", srv_key, inter.subject, inter_key, False)

for c in (root, inter, server):
    print(f"{c.subject.rfc4514_string():22} issued by {c.issuer.rfc4514_string()}")

# ---------- PART C: CHAIN VERIFICATION ----------
signed_by(inter, root)
signed_by(server, inter)
print("\nChain verification: OK (server -> intermediate -> root)")

# ---------- PART D: REVOKE SERVER CERT AND CHECK THE CRL ----------
crl = (x509.CertificateRevocationListBuilder().issuer_name(inter.subject)
       .last_update(now).next_update(now + datetime.timedelta(days=30))
       .add_revoked_certificate(x509.RevokedCertificateBuilder()
             .serial_number(server.serial_number).revocation_date(now).build())
       .sign(inter_key, hashes.SHA256()))
revoked = crl.get_revoked_certificate_by_serial_number(server.serial_number) is not None
print("Server certificate in CRL:", "REVOKED" if revoked else "GOOD")
