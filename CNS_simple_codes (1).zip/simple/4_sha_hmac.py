# ======================================================================
# EXPERIMENT 4 : HASH FUNCTIONS AND HMAC
# File : 4_sha_hmac.py - MD5 / SHA hashes, HMAC and tamper detection
# ======================================================================
#
# WHAT IS INSIDE THIS FILE
#   Part A - Hashes of two messages (MD5, SHA-1, SHA-256, SHA-512)
#   Part B - HMAC-SHA256 of both messages with a secret key
#   Part C - Tamper detection (compares the two HMACs)
#
# HOW TO RUN
#   1. Run          : python 4_sha_hmac.py   (python3 on Linux/macOS)
#
# SAMPLE INPUT : Pay 500  then  Pay 900
#
# EXPECTED OUTPUT (what you will see in the terminal)
#   Original message: Pay 500
#   Modified message: Pay 900
#   md5     original: f14136e2502f09825c574a2e3bb75a42 ...
#   md5     modified: 777d39607cc89e541d98b6134d1b4d32 ...
#   sha1    original: ee621f0851f5becb8ae1d447fc77d115 ...
#   sha1    modified: e8750472fc3908c86a888a8fea5ac3d3 ...
#   sha256  original: 05f028b5d205dda857c12292c7946181 ...
#   sha256  modified: 667b91383ec73b04ad116f0359bd0c8b ...
#   sha512  original: 76ac96e734e42d38dd10d63f1212e651 ...
#   sha512  modified: 46880bff4da709dc29375301c4d1b118 ...
#
#   HMAC original: 96e1ff1621688a44dd4d0121726933027a7faac59f32b20c95c0592bccf833f1
#   HMAC modified: bc18b3e81c14af17bb0b6cb0aa17174a953243490b314ce0899d4dce199411e1
#   Tampering detected? True
# ======================================================================


import hashlib, hmac

# ---------- INPUT: secret key and the two messages ----------
key = b"my-secret-key"
msg1 = input("Original message: ")
msg2 = input("Modified message: ")

# ---------- PART A: HASH VALUES ----------
for name in ["md5", "sha1", "sha256", "sha512"]:
    print(f"{name:7} original:", hashlib.new(name, msg1.encode()).hexdigest()[:32], "...")
    print(f"{name:7} modified:", hashlib.new(name, msg2.encode()).hexdigest()[:32], "...")

# ---------- PART B: HMAC AND PART C: TAMPER DETECTION ----------
mac1 = hmac.new(key, msg1.encode(), hashlib.sha256).hexdigest()
mac2 = hmac.new(key, msg2.encode(), hashlib.sha256).hexdigest()
print("\nHMAC original:", mac1)
print("HMAC modified:", mac2)
print("Tampering detected?", mac1 != mac2)
