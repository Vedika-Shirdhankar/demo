# ======================================================================
# EXPERIMENT 2 : CLASSICAL CIPHERS
# File : 2_cipher.py - Caesar, Vigenere, Playfair, Hill ciphers (fixed simple keys)
# ======================================================================
#
# WHAT IS INSIDE THIS FILE
#   Part A - Caesar cipher (key = 3)
#   Part B - Vigenere cipher (key = KEY)
#   Part C - Playfair cipher (key = MONARCHY)
#   Part D - Hill cipher (key matrix [[3,3],[2,5]])
#
# HOW TO RUN
#   1. Run          : python 2_cipher.py   (python3 on Linux/macOS)
#
# SAMPLE INPUT : HELLO WORLD
#
# EXPECTED OUTPUT (what you will see in the terminal)
#   Enter plaintext: HELLO WORLD
#   Caesar   : KHOORZRUOG
#   Vigenere : RIJVSUYVJN
#   Playfair : CFSUPMVNMTBZ
#   Hill     : HIOZEIPJQL
# ======================================================================


# ---------- INPUT: read plaintext and keep only letters ----------
text = "".join(c for c in input("Enter plaintext: ").upper() if c.isalpha())
A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

# ---------- PART A: CAESAR CIPHER ----------
# Caesar, key = 3
caesar = "".join(A[(A.index(c) + 3) % 26] for c in text)

# ---------- PART B: VIGENERE CIPHER ----------
# Vigenere, key = KEY
key = "KEY"
vig = "".join(A[(A.index(c) + A.index(key[i % 3])) % 26] for i, c in enumerate(text))

# ---------- PART C: PLAYFAIR CIPHER ----------
# Playfair, key = MONARCHY (I and J merged)
k = ""
for c in "MONARCHY" + A.replace("J", ""):
    if c not in k:
        k += c
box = [k[i:i + 5] for i in range(0, 25, 5)]
pos = lambda c: divmod(k.index(c), 5)
t = text.replace("J", "I")
pairs, i = [], 0
while i < len(t):
    x = t[i]
    y = t[i + 1] if i + 1 < len(t) and t[i + 1] != x else "X"
    pairs.append((x, y))
    i += 2 if y != "X" or (i + 1 < len(t) and t[i + 1] == "X") else 1
play = ""
for x, y in pairs:
    (r1, c1), (r2, c2) = pos(x), pos(y)
    if r1 == r2:
        play += box[r1][(c1 + 1) % 5] + box[r2][(c2 + 1) % 5]
    elif c1 == c2:
        play += box[(r1 + 1) % 5][c1] + box[(r2 + 1) % 5][c2]
    else:
        play += box[r1][c2] + box[r2][c1]

# ---------- PART D: HILL CIPHER ----------
# Hill, key matrix [[3,3],[2,5]]
h = text + ("X" if len(text) % 2 else "")
hill = ""
for i in range(0, len(h), 2):
    p, q = A.index(h[i]), A.index(h[i + 1])
    hill += A[(3 * p + 3 * q) % 26] + A[(2 * p + 5 * q) % 26]

# ---------- OUTPUT: print all ciphertexts ----------
print("Caesar   :", caesar)
print("Vigenere :", vig)
print("Playfair :", play)
print("Hill     :", hill)
