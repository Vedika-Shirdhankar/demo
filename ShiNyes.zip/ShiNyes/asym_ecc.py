import random

# Curve parameters
p = 17
a = 2
b = 2

# Base point
G = (5, 1)


# Point addition
def point_add(P, Q):

    # Point at infinity
    if P is None:
        return Q

    if Q is None:
        return P

    x1, y1 = P
    x2, y2 = Q

    # Inverse points
    if x1 == x2 and (y1 + y2) % p == 0:
        return None

    # Point doubling
    if P == Q:
        numerator = (3 * x1 * x1 + a) % p
        denominator = pow(2 * y1, -1, p)

    # Normal point addition
    else:
        numerator = (y2 - y1) % p
        denominator = pow((x2 - x1) % p, -1, p)

    # Calculate slope
    lam = (numerator * denominator) % p

    # Calculate new coordinates
    x3 = (lam * lam - x1 - x2) % p

    y3 = (lam * (x1 - x3) - y1) % p

    return (x3, y3)


# Scalar multiplication
def scalar_multiply(k, P):

    result = None
    current = P

    while k > 0:

        if k % 2 == 1:
            result = point_add(result, current)

        current = point_add(current, current)

        k //= 2

    return result


# ECC Key Generation
def ecc(uid):

    rng = random.Random(int(uid))

    # Base point G has order 19
    order = 19

    # Private keys
    alice_private = rng.randint(1, order - 1)
    bob_private = rng.randint(1, order - 1)

    # Public keys
    alice_public = scalar_multiply(
        alice_private, G
    )

    bob_public = scalar_multiply(
        bob_private, G
    )

    # Shared secrets
    alice_secret = scalar_multiply(
        alice_private, bob_public
    )

    bob_secret = scalar_multiply(
        bob_private, alice_public
    )

    match = alice_secret == bob_secret

    return (
        alice_private,
        alice_public,
        bob_private,
        bob_public,
        alice_secret,
        bob_secret,
        match
    )


uid = 2024300020

result = ecc(uid)

print("Alice Private:", result[0])
print("Alice Public:", result[1])

print("Bob Private:", result[2])
print("Bob Public:", result[3])

print("Alice Shared Secret:", result[4])
print("Bob Shared Secret:", result[5])

print("Secrets Match:", result[6])