import random
import math


def is_prime(n):
    if n < 2:
        return False

    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False

    return True


def generate_prime(rng):
    while True:
        num = rng.randint(300, 700)

        if is_prime(num):
            return num


def prime_factors(n):
    factors = set()

    d = 2
    while d * d <= n:
        while n % d == 0:
            factors.add(d)
            n //= d
        d += 1

    if n > 1:
        factors.add(n)

    return factors


def find_generator(p):
    for g in range(2, p):
        if all(
            pow(g, (p - 1) // f, p) != 1
            for f in prime_factors(p - 1)
        ):
            return g


def elgamal(uid, message):
    rng = random.Random(int(uid))

    # Step 1: Generate parameters
    p = generate_prime(rng)
    g = find_generator(p)

    # Step 2: Generate private key
    x = rng.randint(2, p - 2)

    # Step 3: Generate public key
    y = pow(g, x, p)

    # Step 4: Encrypt each character
    ciphertext = []

    for ch in message:
        m = ord(ch)

        # Generate ephemeral key
        k = rng.randint(2, p - 2)

        while math.gcd(k, p - 1) != 1:
            k = rng.randint(2, p - 2)

        c1 = pow(g, k, p)

        s = pow(y, k, p)

        c2 = (m * s) % p

        ciphertext.append((c1, c2))

    # Step 5: Decrypt
    decrypted = ""

    for c1, c2 in ciphertext:
        s = pow(c1, x, p)

        inverse = pow(s, -1, p)

        m = (c2 * inverse) % p

        decrypted += chr(m)

    return p, g, x, y, ciphertext, decrypted


uid = 2024300020

result = elgamal(uid, "HELLO")

print("p:", result[0])
print("g:", result[1])
print("Private Key:", result[2])
print("Public Key:", result[3])
print("Ciphertext:", result[4])
print("Decrypted:", result[5])