

def jacobi(a, n):
    if n <= 0 or n % 2 == 0:
        raise ValueError("n must be positive and odd")
    a %= n
    result = 1

    while a != 0:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5):
                result = -result

        a, n = n, a
        if a % 4 == 3 and n % 4 == 3:
            result = -result
        a %= n

    return result if n == 1 else 0


def fermat_test(n, bases):
    if n < 2:
        return "Composite"
    if n in (2, 3):
        return "Prime"
    if n % 2 == 0:
        return "Composite"

    for a in bases:
        if pow(a, n - 1, n) != 1:
            return "Composite"
    return "Probably Prime"


def euler_test(n, bases):
    if n < 2:
        return "Composite"
    if n in (2, 3):
        return "Prime"
    if n % 2 == 0:
        return "Composite"

    for a in bases:
        left = pow(a, (n - 1) // 2, n)
        right = jacobi(a, n) % n
        if left != right:
            return "Composite"
    return "Probably Prime"


def miller_rabin_test(n, bases):
    if n < 2:
        return "Composite"
    if n in (2, 3):
        return "Prime"
    if n % 2 == 0:
        return "Composite"

    # Write n - 1 = 2^s * d, with d odd.
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    for a in bases:
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue

        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return "Composite"

    return "Probably Prime"


def gcd(a, b):
    while b:
        a, b = b, a % b
    return abs(a)


def run_all_tests(n, bases):
    print("\nNumber:", n, "| Bases:", bases)
    print("Fermat       :", fermat_test(n, bases))
    print("Euler-Jacobi :", euler_test(n, bases))
    print("Miller-Rabin :", miller_rabin_test(n, bases))


def example_test_cases():
    # The bases shown are valid (coprime to n and between 2 and n-2).
    examples = [
        (7, [2, 3]),          # Prime
        (13, [2, 3, 5]),      # Prime
        (15, [2, 4]),         # Composite
        (21, [2, 5]),         # Composite
        (25, [2, 3]),         # Composite
        (561, [2, 3, 5]),     # Carmichael number
        (1105, [2, 3, 7]),    # Carmichael number
    ]

    print("\n========== EXAMPLE TEST CASES ==========")
    for n, bases in examples:
        run_all_tests(n, bases)
        print("-" * 45)


def main():
    while True:
        print("\n========== PRIMALITY TEST MENU ==========")
        print("1. Fermat Primality Test")
        print("2. Euler-Jacobi Primality Test")
        print("3. Miller-Rabin Primality Test")
        print("4. Run all three tests")
        print("5. Run example test cases")
        print("6. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == "6":
            print("Program terminated.")
            break
        if choice == "5":
            example_test_cases()
            continue
        if choice not in ("1", "2", "3", "4"):
            print("Invalid choice. Try again.")
            continue

        try:
            n = int(input("Enter a number: "))
            bases = list(map(int, input(
                "Enter bases separated by spaces (e.g. 2 3 5): "
            ).split()))

            if not bases:
                print("Please enter at least one base.")
                continue

            # For n > 4, use bases in [2, n-2] coprime to n.
            invalid = [
                a for a in bases
                if n > 4 and (a < 2 or a > n - 2 or gcd(a, n) != 1)
            ]
            if invalid:
                print("Invalid base(s):", invalid)
                print("Choose bases with 2 <= a <= n-2 and gcd(a,n) = 1.")
                continue

            if choice == "1":
                print("Fermat Result:", fermat_test(n, bases))
            elif choice == "2":
                print("Euler-Jacobi Result:", euler_test(n, bases))
            elif choice == "3":
                print("Miller-Rabin Result:", miller_rabin_test(n, bases))
            else:
                run_all_tests(n, bases)

        except ValueError as error:
            print("Invalid input:", error)


if __name__ == "__main__":
    main()
