import random
import math

# Generate prime numbers
def is_prime(n):
    if n < 2:
        return False

    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False

    return True


def generate_prime(rng):
    while True:
        num = rng.randint(100, 500)

        if is_prime(num):
            return num


def rsa(uid, message):
    rng = random.Random(int(uid))

    # Step 1: Generate p and q
    p = generate_prime(rng)

    q = generate_prime(rng)
    while q == p:
        q = generate_prime(rng)

    # Step 2: Calculate n and phi
    n = p * q
    phi = (p - 1) * (q - 1)

    # Step 3: Select e
    e = 65537
    if e >= phi:
        e = 3

    while math.gcd(e, phi) != 1:
        e += 2

    # Step 4: Calculate d
    d = pow(e, -1, phi)

    # Step 5: Encrypt each character
    ciphertext = [
        pow(ord(ch), e, n) for ch in message
    ]

    # Step 6: Decrypt
    decrypted = ''.join(
        chr(pow(c, d, n)) for c in ciphertext
    )

    return p, q, n, phi, e, d, ciphertext, decrypted


uid = 2024300020

result = rsa(uid, "HELLO")

print("p, q, n, phi, e, d:")
print(result[:6])

print("Ciphertext:", result[6])
print("Decrypted:", result[7])