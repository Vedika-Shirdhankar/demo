import csv
import random
import time
import math
import os
import pandas as pd
import matplotlib.pyplot as plt


# ---------------------------------------------------------
# 1. JACOBI SYMBOL
# Used by the Euler-Jacobi primality test.
# ---------------------------------------------------------

def jacobi(a, n):
    if n <= 0 or n % 2 == 0:
        raise ValueError("n must be a positive odd integer")

    a = a % n
    result = 1

    while a != 0:
        while a % 2 == 0:
            a //= 2
            if n % 8 in (3, 5):
                result = -result

        a, n = n, a

        if a % 4 == 3 and n % 4 == 3:
            result = -result

        a = a % n

    if n == 1:
        return result
    return 0


# ---------------------------------------------------------
# 2. FERMAT PRIMALITY TEST
# ---------------------------------------------------------

def fermat_test(n, bases):
    if n < 2:
        return "Composite"
    if n in (2, 3):
        return "Prime"
    if n % 2 == 0:
        return "Composite"

    for a in bases:
        if pow(a, n - 1, n) != 1:
            return "Composite"

    return "Prime"


# ---------------------------------------------------------
# 3. EULER-JACOBI PRIMALITY TEST
# ---------------------------------------------------------

def euler_test(n, bases):
    if n < 2:
        return "Composite"
    if n in (2, 3):
        return "Prime"
    if n % 2 == 0:
        return "Composite"

    for a in bases:
        left_side = pow(a, (n - 1) // 2, n)
        right_side = jacobi(a, n) % n

        if left_side != right_side:
            return "Composite"

    return "Prime"


# ---------------------------------------------------------
# 4. MILLER-RABIN PRIMALITY TEST
# ---------------------------------------------------------

def miller_rabin_test(n, bases):
    if n < 2:
        return "Composite"
    if n in (2, 3):
        return "Prime"
    if n % 2 == 0:
        return "Composite"

    # Write n - 1 as (2 ** s) * d, where d is odd.
    d = n - 1
    s = 0

    while d % 2 == 0:
        d //= 2
        s += 1

    for a in bases:
        x = pow(a, d, n)

        if x == 1 or x == n - 1:
            continue

        for _ in range(s - 1):
            x = pow(x, 2, n)

            if x == n - 1:
                break
        else:
            return "Composite"

    return "Prime"


# ---------------------------------------------------------
# 5. GENERATE FIVE BASES FROM THE 10-DIGIT UID
# ---------------------------------------------------------

def generate_uid_bases(uid):
    uid = str(uid).strip()

    if not uid.isdigit() or len(uid) != 10:
        raise ValueError("UID must contain exactly 10 digits.")

    digits = [int(x) for x in uid]

    base1 = (int(uid[-2:]) % 97) + 2
    base2 = (sum(digits) % 97) + 2
    base3 = ((int(uid[:4]) + int(uid[-4:])) % 97) + 2
    base4 = (sum(digits[0::2]) % 97) + 2
    base5 = (sum(digits[1::2]) % 97) + 2

    return [base1, base2, base3, base4, base5]


# ---------------------------------------------------------
# 6. MAKE BASES VALID FOR A PARTICULAR NUMBER
# ---------------------------------------------------------

def get_valid_bases(n, uid_bases, rng):
    """
    A valid base must satisfy:
    2 <= base <= n - 2 and gcd(base, n) == 1.

    If an original UID base is invalid, replace it with a
    randomly generated valid base. The same resulting bases
    are used by all three algorithms for this number.
    """

    if n <= 4:
        return []

    valid_bases = []

    for base in uid_bases:
        if 2 <= base <= n - 2 and math.gcd(base, n) == 1:
            valid_bases.append(base)
        else:
            # Generate a replacement base.
            while True:
                new_base = rng.randint(2, n - 2)
                if math.gcd(new_base, n) == 1:
                    valid_bases.append(new_base)
                    break

    return valid_bases


# ---------------------------------------------------------
# 7. MEASURE EXECUTION TIME
# ---------------------------------------------------------

def test_with_time(test_function, n, bases):
    start = time.perf_counter()
    result = test_function(n, bases)
    end = time.perf_counter()

    time_ms = (end - start) * 1000
    return result, time_ms


# ---------------------------------------------------------
# 8. NORMALIZE ACTUAL CLASSIFICATION
# ---------------------------------------------------------

def normalize_actual(value):
    value = str(value).strip().lower()

    if value == "prime":
        return "Prime"

    # Carmichael numbers are composite numbers.
    if value in ("composite", "carmichael"):
        return "Composite"

    raise ValueError(
        f"Unknown Actual_Type value: {value}. "
        "Expected Prime, Composite, or Carmichael."
    )


# ---------------------------------------------------------
# 9. CALCULATE PERFORMANCE METRICS
# ---------------------------------------------------------

def calculate_metrics(df, result_column, time_column):
    actual = df["Actual_Normalized"]
    predicted = df[result_column]

    correct = (actual == predicted).sum()
    incorrect = len(df) - correct

    false_positives = (
        (actual == "Composite") & (predicted == "Prime")
    ).sum()

    false_negatives = (
        (actual == "Prime") & (predicted == "Composite")
    ).sum()

    accuracy = (correct / len(df)) * 100 if len(df) else 0
    average_time = df[time_column].mean() if len(df) else 0

    return {
        "Algorithm": result_column.replace("_Result", ""),
        "Correct": int(correct),
        "Incorrect": int(incorrect),
        "False_Positives": int(false_positives),
        "False_Negatives": int(false_negatives),
        "Accuracy_Percent": accuracy,
        "Average_Time_ms": average_time
    }


# ---------------------------------------------------------
# 10. MAIN EXPERIMENT
# ---------------------------------------------------------

def main():
    print("\n==============================================")
    print(" PROBABILISTIC PRIMALITY TESTING EXPERIMENT")
    print("==============================================")

    uid = input("Enter your 10-digit UID: ").strip()

    try:
        uid_bases = generate_uid_bases(uid)
    except ValueError as error:
        print("Error:", error)
        return

    print("\nUID-derived bases:", uid_bases)

    input_file = input(
        "\nEnter CSV filename (default: primality_dataset_1000.csv): "
    ).strip()

    if input_file == "":
        input_file = "primality_dataset_1000.csv"

    if not os.path.exists(input_file):
        print("\nDataset file not found:", input_file)
        print("Keep the CSV in the same folder as this Python file.")
        return

    try:
        df = pd.read_csv(input_file)
    except Exception as error:
        print("Could not read CSV:", error)
        return

    # Find the number column.
    if "Number" in df.columns:
        number_column = "Number"
    else:
        possible_columns = [
            col for col in df.columns
            if col.lower() in ("n", "value", "number_to_test")
        ]

        if possible_columns:
            number_column = possible_columns[0]
        else:
            possible_columns = [
                col for col in df.columns if col != "Actual_Type"
            ]

            if not possible_columns:
                print("Could not find the number column in the CSV.")
                return

            number_column = possible_columns[0]

    if "Actual_Type" not in df.columns:
        print("CSV must contain an 'Actual_Type' column.")
        return

    # Use a reproducible random generator based on UID.
    rng = random.Random(int(uid))

    # Actual_Type is not passed into any primality test.
    df["Actual_Normalized"] = df["Actual_Type"].apply(normalize_actual)

    fermat_results = []
    euler_results = []
    mr_results = []

    fermat_times = []
    euler_times = []
    mr_times = []

    used_bases_list = []

    print("\nRunning tests on", len(df), "numbers...")

    for number in df[number_column]:
        n = int(number)

        # The same five valid bases are used by all algorithms.
        bases = get_valid_bases(n, uid_bases, rng)
        used_bases_list.append(",".join(map(str, bases)))

        result, elapsed = test_with_time(fermat_test, n, bases)
        fermat_results.append(result)
        fermat_times.append(elapsed)

        result, elapsed = test_with_time(euler_test, n, bases)
        euler_results.append(result)
        euler_times.append(elapsed)

        result, elapsed = test_with_time(miller_rabin_test, n, bases)
        mr_results.append(result)
        mr_times.append(elapsed)

    # Add results to the dataset.
    df["Bases_Used"] = used_bases_list

    df["Fermat_Result"] = fermat_results
    df["Fermat_Time_ms"] = fermat_times

    df["Euler_Result"] = euler_results
    df["Euler_Time_ms"] = euler_times

    df["MillerRabin_Result"] = mr_results
    df["MillerRabin_Time_ms"] = mr_times

    # Calculate summary metrics.
    summary = pd.DataFrame([
        calculate_metrics(df, "Fermat_Result", "Fermat_Time_ms"),
        calculate_metrics(df, "Euler_Result", "Euler_Time_ms"),
        calculate_metrics(df, "MillerRabin_Result", "MillerRabin_Time_ms")
    ])

    # Count Carmichael numbers incorrectly identified as prime by Fermat.
    carmichael_mask = (
        df["Actual_Type"].astype(str).str.strip().str.lower()
        == "carmichael"
    )
    carmichael_fermat_false_positives = (
        carmichael_mask & (df["Fermat_Result"] == "Prime")
    ).sum()

    # Save output files.
    output_file = os.path.splitext(input_file)[0] + "_results.csv"
    summary_file = os.path.splitext(input_file)[0] + "_summary.csv"

    # Drop helper column from the detailed output.
    df.drop(columns=["Actual_Normalized"]).to_csv(
        output_file, index=False
    )
    summary.to_csv(summary_file, index=False)

    # -----------------------------------------------------
    # 11. GENERATE GRAPHS
    # -----------------------------------------------------

    # Accuracy graph.
    plt.figure()
    plt.bar(summary["Algorithm"], summary["Accuracy_Percent"])
    plt.title("Accuracy Comparison")
    plt.xlabel("Algorithm")
    plt.ylabel("Accuracy (%)")
    plt.ylim(0, 100)
    plt.tight_layout()
    plt.savefig("accuracy_comparison.png")
    plt.close()

    # Average execution time graph.
    plt.figure()
    plt.bar(summary["Algorithm"], summary["Average_Time_ms"])
    plt.title("Average Execution Time Comparison")
    plt.xlabel("Algorithm")
    plt.ylabel("Average Time (ms)")
    plt.tight_layout()
    plt.savefig("execution_time_comparison.png")
    plt.close()

    # False positives graph.
    plt.figure()
    plt.bar(summary["Algorithm"], summary["False_Positives"])
    plt.title("False Positives Comparison")
    plt.xlabel("Algorithm")
    plt.ylabel("Number of False Positives")
    plt.tight_layout()
    plt.savefig("false_positives_comparison.png")
    plt.close()

    # -----------------------------------------------------
    # 12. DISPLAY SUMMARY
    # -----------------------------------------------------

    print("\n========== SUMMARY TABLE ==========")
    print(summary.to_string(index=False))

    print(
        "\nCarmichael numbers incorrectly identified as Prime "
        "by Fermat:",
        int(carmichael_fermat_false_positives)
    )

    print("\n========== GENERATED FILES ==========")
    print("1.", output_file)
    print("2.", summary_file)
    print("3. accuracy_comparison.png")
    print("4. execution_time_comparison.png")
    print("5. false_positives_comparison.png")

    print("\nExperiment completed successfully!")


if __name__ == "__main__":
    main()
