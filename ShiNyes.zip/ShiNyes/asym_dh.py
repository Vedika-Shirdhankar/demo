import random
import math


def is_prime(n):
    if n < 2:
        return False

    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False

    return True


def generate_prime(rng):
    while True:
        num = rng.randint(300, 700)

        if is_prime(num):
            return num


def prime_factors(n):
    factors = set()

    d = 2

    while d * d <= n:
        while n % d == 0:
            factors.add(d)
            n //= d
        d += 1

    if n > 1:
        factors.add(n)

    return factors


def find_generator(p):
    for g in range(2, p):
        if all(
            pow(g, (p - 1) // f, p) != 1
            for f in prime_factors(p - 1)
        ):
            return g


def diffie_hellman(uid):
    rng = random.Random(int(uid))

    # Step 1: Public parameters
    p = generate_prime(rng)
    g = find_generator(p)

    # Step 2: Private keys
    a = rng.randint(2, p - 2)
    b = rng.randint(2, p - 2)

    # Step 3: Public values
    A = pow(g, a, p)
    B = pow(g, b, p)

    # Step 4: Shared secrets
    alice_secret = pow(B, a, p)
    bob_secret = pow(A, b, p)

    # Step 5: Verify
    match = alice_secret == bob_secret

    return (
        p, g, a, A, b, B,
        alice_secret, bob_secret, match
    )


uid = 2024300020

result = diffie_hellman(uid)

print("Prime p:", result[0])
print("Generator g:", result[1])

print("Alice Private:", result[2])
print("Alice Public:", result[3])

print("Bob Private:", result[4])
print("Bob Public:", result[5])

print("Alice Secret:", result[6])
print("Bob Secret:", result[7])

print("Secrets Match:", result[8])