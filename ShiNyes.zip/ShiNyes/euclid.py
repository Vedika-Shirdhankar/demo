


def gcd(a, b):
    print("\nq\t r1\t r2\t r")

    while b != 0:
        q = a // b
        r = a % b

        print(q, "\t", a, "\t", b, "\t", r)

        a = b
        b = r

    print("\nGCD =", a)



def extended_gcd(a, b):
    r1, r2 = a, b
    s1, s2 = 1, 0
    t1, t2 = 0, 1

    print("\nq\t r1\t r2\t r\t s1\t s2\t s\t t1\t t2\t t")

    while r2 != 0:
        q = r1 // r2
        r = r1 % r2

        s = s1 - s2 * q
        t = t1 - t2 * q

        print(q, "\t", r1, "\t", r2, "\t", r,
              "\t", s1, "\t", s2, "\t", s,
              "\t", t1, "\t", t2, "\t", t)

        r1, r2 = r2, r
        s1, s2 = s2, s
        t1, t2 = t2, t

    print("\nGCD =", r1)
    print("s =", s1)
    print("t =", t1)

    print("\nVerification:", a, "*", s1, "+", b, "*", t1, "=", r1)




def multiplicative_inverse(a, b):
    r1, r2 = a, b
    t1, t2 = 0, 1

    print("\nq\t r1\t r2\t r\t t1\t t2\t t")

    while r2 != 0:
        q = r1 // r2
        r = r1 % r2

        t = t1 - t2 * q

        print(q, "\t", r1, "\t", r2, "\t", r,
              "\t", t1, "\t", t2, "\t", t)

        r1, r2 = r2, r
        t1, t2 = t2, t

    print("\nGCD =", r1)

    if r1 == 1:
        inverse = t1 % a
        print("Multiplicative Inverse =", inverse)
    else:
        print("Multiplicative Inverse does not exist!")



while True:

    print("\n========== MENU ==========")
    print("1. Basic Euclidean Algorithm (GCD)")
    print("2. Extended Euclidean Algorithm (GCD, s, t)")
    print("3. Euclidean Algorithm (Multiplicative Inverse)")
    print("4. Quit")

    choice = int(input("\nEnter your choice: "))

    if choice == 4:
        print("Program Terminated!")
        break

    if choice in [1, 2, 3]:

        a = int(input("Enter first number: "))
        b = int(input("Enter second number: "))

        if a <= 0 or b <= 0:
            print("Please enter positive integers!")
            continue

        if choice == 1:
            gcd(a, b)

        elif choice == 2:
            extended_gcd(a, b)

        elif choice == 3:
            multiplicative_inverse(a, b)

    else:
        print("Invalid Choice! Please try again.")
