
import random
import math
import string

ALPHABET = string.ascii_uppercase


# ============================================================
# COMMON FUNCTIONS
# ============================================================

def clean_text(text):
    """Keep only alphabetic English characters and convert to uppercase."""
    return ''.join(ch for ch in text.upper() if ch in ALPHABET)


def extended_gcd(a, b):
    """Calculate GCD and Bezout coefficients."""
    if b == 0:
        return a, 1, 0

    gcd, x1, y1 = extended_gcd(b, a % b)

    x = y1
    y = x1 - (a // b) * y1

    return gcd, x, y


def mod_inverse(a, m):
    """Find modular multiplicative inverse."""
    gcd, x, y = extended_gcd(a, m)

    if gcd != 1:
        raise ValueError("Modular inverse does not exist")

    return x % m


# ============================================================
# UID-BASED KEY GENERATION
# ============================================================

def generate_keys(uid):

    uid = str(uid)

    if len(uid) != 10 or not uid.isdigit():
        raise ValueError("UID must contain exactly 10 digits")

    # 1. Caesar Key
    caesar_key = (sum(int(digit) for digit in uid) % 25) + 1

    # 2. Monoalphabetic Key
    shuffled_alphabet = list(ALPHABET)

    rng = random.Random(int(uid))
    rng.shuffle(shuffled_alphabet)

    mono_key = ''.join(shuffled_alphabet)

    # 3. Vigenere Key
    groups = [uid[i:i+2] for i in range(0, 10, 2)]

    vigenere_key = ''.join(
        ALPHABET[int(group) % 26]
        for group in groups
    )

    # 4. Playfair Keyword
    playfair_key = ''.join(dict.fromkeys(vigenere_key))

    # 5. Hill Cipher Key
    # Use the first four TWO-DIGIT groups.
    hill_values = [
        int(uid[i:i+2]) % 26
        for i in range(0, 8, 2)
    ]

    hill_key = [
        [hill_values[0], hill_values[1]],
        [hill_values[2], hill_values[3]]
    ]

    # Ensure determinant is relatively prime to 26
    while True:

        a, b = hill_key[0]
        c, d = hill_key[1]

        determinant = (a * d - b * c) % 26

        if math.gcd(determinant, 26) == 1:
            break

        hill_key[1][1] = (hill_key[1][1] + 1) % 26

    return {
        "caesar": caesar_key,
        "mono": mono_key,
        "vigenere": vigenere_key,
        "playfair": playfair_key,
        "hill": hill_key
    }


# ============================================================
# 1. CAESAR CIPHER
# ============================================================

def caesar_encrypt(plaintext, key):

    plaintext = clean_text(plaintext)
    ciphertext = ""

    for char in plaintext:

        position = ALPHABET.index(char)

        new_position = (position + key) % 26

        ciphertext += ALPHABET[new_position]

    return ciphertext


def caesar_decrypt(ciphertext, key):

    ciphertext = clean_text(ciphertext)
    plaintext = ""

    for char in ciphertext:

        position = ALPHABET.index(char)

        new_position = (position - key) % 26

        plaintext += ALPHABET[new_position]

    return plaintext


# ============================================================
# 2. MONOALPHABETIC SUBSTITUTION CIPHER
# ============================================================

def mono_encrypt(plaintext, key):

    plaintext = clean_text(plaintext)

    mapping = dict(zip(ALPHABET, key))

    ciphertext = ""

    for char in plaintext:
        ciphertext += mapping[char]

    return ciphertext


def mono_decrypt(ciphertext, key):

    ciphertext = clean_text(ciphertext)

    reverse_mapping = dict(zip(key, ALPHABET))

    plaintext = ""

    for char in ciphertext:
        plaintext += reverse_mapping[char]

    return plaintext


# ============================================================
# 3. VIGENERE CIPHER
# ============================================================

def vigenere_encrypt(plaintext, key):

    plaintext = clean_text(plaintext)

    ciphertext = ""

    for i in range(len(plaintext)):

        p = ord(plaintext[i]) - ord('A')

        k = ord(key[i % len(key)]) - ord('A')

        c = (p + k) % 26

        ciphertext += chr(c + ord('A'))

    return ciphertext


def vigenere_decrypt(ciphertext, key):

    ciphertext = clean_text(ciphertext)

    plaintext = ""

    for i in range(len(ciphertext)):

        c = ord(ciphertext[i]) - ord('A')

        k = ord(key[i % len(key)]) - ord('A')

        p = (c - k) % 26

        plaintext += chr(p + ord('A'))

    return plaintext


# ============================================================
# 4. PLAYFAIR CIPHER
# ============================================================

def generate_playfair_matrix(keyword):

    keyword = clean_text(keyword)

    # Remove duplicate letters
    keyword = ''.join(dict.fromkeys(keyword))

    # I and J are treated as the same letter
    keyword = keyword.replace('J', 'I')

    matrix_letters = []

    for char in keyword + ALPHABET:

        if char == 'J':
            char = 'I'

        if char not in matrix_letters:
            matrix_letters.append(char)

    # Remove J to create a 5x5 matrix
    matrix_letters = matrix_letters[:25]

    matrix = [
        matrix_letters[i:i+5]
        for i in range(0, 25, 5)
    ]

    return matrix


def prepare_playfair_text(plaintext):

    plaintext = clean_text(plaintext)

    # Store positions of original J characters
    j_positions = [
        i for i, char in enumerate(plaintext) if char == 'J'
    ]

    plaintext = plaintext.replace('J', 'I')

    prepared = []
    inserted_positions = []

    i = 0

    while i < len(plaintext):

        first = plaintext[i]
        prepared.append(first)

        if i + 1 < len(plaintext):

            second = plaintext[i + 1]

            if first == second:

                filler = 'Q' if first == 'X' else 'X'

                prepared.append(filler)
                inserted_positions.append(len(prepared) - 1)

                i += 1

            else:

                prepared.append(second)
                i += 2

        else:

            filler = 'Q' if first == 'X' else 'X'

            prepared.append(filler)
            inserted_positions.append(len(prepared) - 1)

            i += 1

    return ''.join(prepared), inserted_positions, j_positions


def playfair_encrypt(plaintext, keyword):

    matrix = generate_playfair_matrix(keyword)

    prepared, inserted_positions, j_positions = (
        prepare_playfair_text(plaintext)
    )

    # Store letter positions in the matrix
    positions = {}

    for row in range(5):
        for col in range(5):
            positions[matrix[row][col]] = (row, col)

    ciphertext = ""

    for i in range(0, len(prepared), 2):

        a = prepared[i]
        b = prepared[i + 1]

        row1, col1 = positions[a]
        row2, col2 = positions[b]

        # Same row: shift right
        if row1 == row2:

            ciphertext += matrix[row1][(col1 + 1) % 5]
            ciphertext += matrix[row2][(col2 + 1) % 5]

        # Same column: shift down
        elif col1 == col2:

            ciphertext += matrix[(row1 + 1) % 5][col1]
            ciphertext += matrix[(row2 + 1) % 5][col2]

        # Rectangle rule: exchange columns
        else:

            ciphertext += matrix[row1][col2]
            ciphertext += matrix[row2][col1]

    metadata = {
        "inserted_positions": inserted_positions,
        "j_positions": j_positions
    }

    return ciphertext, metadata


def playfair_decrypt(ciphertext, keyword, metadata=None):

    matrix = generate_playfair_matrix(keyword)

    ciphertext = clean_text(ciphertext)

    positions = {}

    for row in range(5):
        for col in range(5):
            positions[matrix[row][col]] = (row, col)

    plaintext = ""

    for i in range(0, len(ciphertext), 2):

        a = ciphertext[i]
        b = ciphertext[i + 1]

        row1, col1 = positions[a]
        row2, col2 = positions[b]

        # Same row: shift left
        if row1 == row2:

            plaintext += matrix[row1][(col1 - 1) % 5]
            plaintext += matrix[row2][(col2 - 1) % 5]

        # Same column: shift up
        elif col1 == col2:

            plaintext += matrix[(row1 - 1) % 5][col1]
            plaintext += matrix[(row2 - 1) % 5][col2]

        # Rectangle rule
        else:

            plaintext += matrix[row1][col2]
            plaintext += matrix[row2][col1]

    # Remove automatically inserted filler characters
    # and restore original J characters.
    if metadata is not None:

        chars = list(plaintext)

        for position in sorted(
            metadata["inserted_positions"], reverse=True
        ):
            chars.pop(position)

        for position in metadata["j_positions"]:
            chars[position] = 'J'

        plaintext = ''.join(chars)

    return plaintext


# ============================================================
# 5. HILL CIPHER
# ============================================================

def hill_encrypt(plaintext, key):

    plaintext = clean_text(plaintext)

    original_length = len(plaintext)

    # Padding for odd-length plaintext
    if len(plaintext) % 2 != 0:
        plaintext += 'X'

    ciphertext = ""

    for i in range(0, len(plaintext), 2):

        # Convert letters into numbers (A=0, B=1...Z=25)
        p1 = ord(plaintext[i]) - ord('A')
        p2 = ord(plaintext[i+1]) - ord('A')

        # Matrix multiplication
        c1 = (key[0][0] * p1 + key[0][1] * p2) % 26

        c2 = (key[1][0] * p1 + key[1][1] * p2) % 26

        ciphertext += chr(c1 + ord('A'))
        ciphertext += chr(c2 + ord('A'))

    metadata = {
        "original_length": original_length
    }

    return ciphertext, metadata


def hill_decrypt(ciphertext, key, metadata=None):

    ciphertext = clean_text(ciphertext)

    a, b = key[0]
    c, d = key[1]

    # Calculate determinant
    determinant = (a * d - b * c) % 26

    # Modular inverse of determinant
    inverse_det = mod_inverse(determinant, 26)

    # Inverse matrix using adjugate
    inverse_key = [
        [(d * inverse_det) % 26, (-b * inverse_det) % 26],
        [(-c * inverse_det) % 26, (a * inverse_det) % 26]
    ]

    plaintext = ""

    for i in range(0, len(ciphertext), 2):

        c1 = ord(ciphertext[i]) - ord('A')
        c2 = ord(ciphertext[i+1]) - ord('A')

        p1 = (
            inverse_key[0][0] * c1 +
            inverse_key[0][1] * c2
        ) % 26

        p2 = (
            inverse_key[1][0] * c1 +
            inverse_key[1][1] * c2
        ) % 26

        plaintext += chr(p1 + ord('A'))
        plaintext += chr(p2 + ord('A'))

    # Remove padding added during encryption
    if metadata is not None:
        plaintext = plaintext[:metadata["original_length"]]

    return plaintext


# ============================================================
# MAIN FUNCTION: TEST ALL FIVE CIPHERS
# ============================================================

def main():

    uid = input("Enter your 10-digit UID: ")

    keys = generate_keys(uid)

    plaintext = input("\nEnter plaintext: ")

    print("\n========== GENERATED KEYS ==========")

    print("Caesar Key:", keys["caesar"])
    print("Monoalphabetic Key:", keys["mono"])
    print("Vigenere Key:", keys["vigenere"])
    print("Playfair Keyword:", keys["playfair"])
    print("Hill Key:", keys["hill"])

    print("\n========== ENCRYPTION & DECRYPTION ==========")

    # 1. Caesar
    encrypted = caesar_encrypt(plaintext, keys["caesar"])
    decrypted = caesar_decrypt(encrypted, keys["caesar"])

    print("\nCAESAR")
    print("Encrypted:", encrypted)
    print("Decrypted:", decrypted)

    # 2. Monoalphabetic
    encrypted = mono_encrypt(plaintext, keys["mono"])
    decrypted = mono_decrypt(encrypted, keys["mono"])

    print("\nMONOALPHABETIC")
    print("Encrypted:", encrypted)
    print("Decrypted:", decrypted)

    # 3. Vigenere
    encrypted = vigenere_encrypt(plaintext, keys["vigenere"])
    decrypted = vigenere_decrypt(encrypted, keys["vigenere"])

    print("\nVIGENERE")
    print("Encrypted:", encrypted)
    print("Decrypted:", decrypted)

    # 4. Playfair
    encrypted, pf_metadata = playfair_encrypt(
        plaintext, keys["playfair"]
    )

    decrypted = playfair_decrypt(
        encrypted, keys["playfair"], pf_metadata
    )

    print("\nPLAYFAIR")
    print("Encrypted:", encrypted)
    print("Decrypted:", decrypted)

    # 5. Hill
    encrypted, hill_metadata = hill_encrypt(
        plaintext, keys["hill"]
    )

    decrypted = hill_decrypt(
        encrypted, keys["hill"], hill_metadata
    )

    print("\nHILL")
    print("Encrypted:", encrypted)
    print("Decrypted:", decrypted)

    print("\n========== VERIFICATION ==========")

    original = clean_text(plaintext)

    results = [
        ("Caesar", caesar_decrypt(
            caesar_encrypt(plaintext, keys["caesar"]),
            keys["caesar"]
        )),

        ("Monoalphabetic", mono_decrypt(
            mono_encrypt(plaintext, keys["mono"]),
            keys["mono"]
        )),

        ("Vigenere", vigenere_decrypt(
            vigenere_encrypt(plaintext, keys["vigenere"]),
            keys["vigenere"]
        )),

        ("Playfair", playfair_decrypt(
            *playfair_encrypt(plaintext, keys["playfair"])[:1],
            keys["playfair"],
            playfair_encrypt(plaintext, keys["playfair"])[1]
        )),

        ("Hill", hill_decrypt(
            hill_encrypt(plaintext, keys["hill"])[0],
            keys["hill"],
            hill_encrypt(plaintext, keys["hill"])[1]
        ))
    ]

    for name, result in results:
        print(
            name + ":",
            "PASS" if result == original else "FAIL"
        )


if __name__ == "__main__":
    main()
